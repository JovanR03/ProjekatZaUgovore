﻿namespace test1.Components.Services
{
    public class FileCheckerService
    {
        public string ProveraFajla {  get; set; }   
        public string DodajNoviFajl { get; set; }
        public string Izbrisifajl { get; set; }

        // provera fajla
        // dodaj novi
        // izbrisi
    }
}
