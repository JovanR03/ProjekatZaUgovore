using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContractManagerApp.Views
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
