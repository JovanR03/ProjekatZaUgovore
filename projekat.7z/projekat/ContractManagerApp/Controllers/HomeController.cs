using System.Diagnostics;
using System.Security.Cryptography;
using ContractManagerApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace ContractManagerApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CheckContracts(DateTime startDate, DateTime endDate)
        {
            TimeSpan remaining = endDate - DateTime.Now;
            ViewBag.DaysLeft = remaining.Days;
            ViewBag.Warning = remaining.TotalDays <= 60;
            return View("Index");
        }

        [HttpPost]
        public IActionResult CheckDuplicates(string folderPath)
        {
            if (!Directory.Exists(folderPath)) return View("Index");

            var fileGroups = Directory.GetFiles(folderPath)
                .GroupBy(f => GetFileHash(f))
                .Where(g => g.Count() > 1)
                .ToList();

            ViewBag.Duplicates = fileGroups;

            return View("Index");
        }

        private string GetFileHash(string filePath)
        {
            using var md5 = MD5.Create();
            using var stream = System.IO.File.OpenRead(filePath);
            var hash = md5.ComputeHash(stream);
            return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
        }

        [HttpPost]
        public IActionResult CheckContract(DateTime signDate, DateTime endDate)
        {
            var daysLeft = (endDate - DateTime.Today).TotalDays;
            ViewBag.SignDate = signDate;
            ViewBag.EndDate = endDate;
            ViewBag.DaysLeft = daysLeft;
            ViewBag.ExpireSoon = daysLeft <= 60;

            return View("Index");
        }
/*
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }*/
    }
}
